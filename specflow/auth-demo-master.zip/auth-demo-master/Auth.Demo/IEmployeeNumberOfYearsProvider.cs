﻿namespace Auth.Demo
{
    public interface IEmployeeNumberOfYearsProvider
    {
        int Get(string value);
    }
}