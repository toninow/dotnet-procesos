﻿namespace Auth.Demo
{
    public interface IRefreshTokenGenerator
    {
        string GenerateToken();
    }
}
