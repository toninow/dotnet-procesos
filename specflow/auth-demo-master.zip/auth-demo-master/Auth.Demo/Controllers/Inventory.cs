﻿namespace Auth.Demo.Controllers
{
    public class Inventory
    {
    }
}